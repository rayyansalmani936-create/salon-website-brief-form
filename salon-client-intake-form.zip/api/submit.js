const nodemailer = require("nodemailer");

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ ok: false, message: "POST method required." });
  }

  const data = req.body;
  if (!data || typeof data !== "object" || Array.isArray(data)) {
    return res.status(400).json({ ok: false, message: "Form data is missing." });
  }

  // Ignore automated submissions that fill the hidden honeypot field.
  if (String(data.website || "").trim()) {
    return res.status(200).json({ ok: true });
  }

  const salonName = cleanText(data["Salon name"], 150).trim();
  const phone = cleanText(data["Phone number"], 50).trim();
  const location = cleanText(data["Salon location"], 250).trim();
  if (!salonName || !phone || !location) {
    return res.status(400).json({ ok: false, message: "Please fill in the required salon details." });
  }

  const gmailUser = process.env.GMAIL_USER;
  const gmailAppPassword = process.env.GMAIL_APP_PASSWORD;
  const ownerEmail = process.env.OWNER_EMAIL;
  if (!gmailUser || !gmailAppPassword || !ownerEmail) {
    console.error("Missing email environment variables.");
    return res.status(500).json({ ok: false, message: "Email setup is not complete yet." });
  }

  const answers = Object.entries(data)
    .filter(([question]) => question !== "website")
    .map(([question, rawAnswer]) => {
      const answer = Array.isArray(rawAnswer) ? rawAnswer.join(", ") : String(rawAnswer || "");
      return `${cleanText(question, 250)}:\n${cleanText(answer, 3000) || "—"}`;
    });

  const contactEmail = cleanText(data["Business email"], 200).trim();
  const replyTo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contactEmail) ? contactEmail : undefined;
  const subjectName = salonName.replace(/[\r\n]+/g, " ").slice(0, 100);
  const text = [
    "A new salon website enquiry was submitted.",
    `Salon: ${salonName}`,
    `Phone: ${phone}`,
    `Location: ${location}`,
    "",
    ...answers
  ].join("\n\n");

  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: { user: gmailUser, pass: gmailAppPassword }
    });

    await transporter.sendMail({
      from: `Salon Website Form <${gmailUser}>`,
      to: ownerEmail,
      replyTo,
      subject: `Salon website enquiry — ${subjectName}`,
      text
    });

    return res.status(200).json({ ok: true });
  } catch (error) {
    console.error("Could not send salon form email.", error && error.message);
    return res.status(500).json({ ok: false, message: "We could not send the email. Please try again later." });
  }
};

function cleanText(value, maxLength) {
  return String(value == null ? "" : value)
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "")
    .slice(0, maxLength);
}
